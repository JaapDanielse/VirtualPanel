﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VirtualPanel
{
    public partial class StatisticsForm : Form
    {
        public StatisticsForm()
        {
            InitializeComponent();
        }

        public void Write_Label( int labelnum, string value)
        {
            switch (labelnum)
            {
                case 1: { label1.Text = value; break; }
                case 2: { label2.Text = value; break; }
                case 3: { label3.Text = value; break; }
                case 4: { label4.Text = value; break; }
                case 5: { label5.Text = value; break; }
                case 6: { label6.Text = value; break; }
            }
        }

        public void WriteMonitor(String inputline)
        {
            if (textBox1.Lines.Length >= 1000)
                textBox1.Text = "";
            textBox1.AppendText(inputline + "\n");
        }


        private void StatisticsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Visible = false;
            e.Cancel = true;

        }
    }
}
