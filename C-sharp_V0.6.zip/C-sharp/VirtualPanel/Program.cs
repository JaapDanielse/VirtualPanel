﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VirtualPanel
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string bull = "[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n[PANEL01V01]\r\n2A1TCNT1L: 000\r\n"  +
                          "2B1Overflow: 000 \r\n2C1Micros: 999920 \r\n"    +
                          "291TCNT1H: 000\r\n2A1TCNT1L: 000\r\n"    +
                          "2B1Overflow: 000 \r\n2C1Micros: 1000960 \r\n"    +
                          "291TCNT1H: 000\r\n2A1TCNT1L: 000\r\n"    +
                          "2B1Overflow: 000 \r\n2C1Micros: 999916 \r\n"    +
                          "291TCNT1H: 000\r\n2A1TCNT1L: 000\r\n"    +
                          "2B1Overflow: 000 \r\n2C1Micros: 1000960 \r\n"    +
                          "291TCNT1H: 000\r\n2A1TCNT1L: 000\r\n"    +
                          "2B1Overflow: 000 \r\n2C1Micros: 999920 \r\n"    +
                          "291TCNT1H: 000\r\n2A1TCNT1L: 000\r\n"   +
                          "2B1Overflow: 000 \r\n2C1Micros";

            //bullshit(bull);
            //bullshit(bull);


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new VirtualPanelForm());
        }

        public static void bullshit(string bullshit)
        {

            Stopwatch stop = new Stopwatch();

            stop.Start();

            // Attached to port receive event (PORT thread)

            string temp = bullshit;

            string[] chunks = temp.Split("\r\n".ToCharArray(), StringSplitOptions.None);

            if (chunks.Last() != "")
            {
                chunks[chunks.Length - 1] = "";
            }

            foreach (var data in chunks)
            {
                Debug.WriteLine(data);

                if (data.Length <= 3)
                    continue;

                int channel;
                if (!int.TryParse(data.Substring(0, 2), NumberStyles.HexNumber, null, out channel))
                    continue;

                int type_temp;
                if (!int.TryParse(data.Substring(2, 1), NumberStyles.HexNumber, null, out type_temp))
                    continue;

                vp_type type = (vp_type)type_temp;

                string value_string = data.Substring(3, data.Length-3);
                object messagedata = null;

                try
                {
                    switch (type)
                    {
                        case vp_type.vp_string:
                            messagedata = value_string;
                            break;
                        case vp_type.vp_boolean:
                            messagedata = Convert.ToBoolean(Convert.ToInt32(value_string, 16));
                            break;
                        case vp_type.vp_byte:
                            messagedata = Convert.ToByte(Convert.ToInt32(value_string, 16));
                            break;
                        case vp_type.vp_int:
                            messagedata = Convert.ToInt32(value_string, 16);
                            break;
                        case vp_type.vp_uint:
                            messagedata = Convert.ToUInt32(value_string, 16);
                            break;
                        case vp_type.vp_long:
                            messagedata = Convert.ToInt64(value_string, 16);
                            break;
                        case vp_type.vp_ulong:
                            messagedata = Convert.ToUInt64(value_string, 16);
                            break;
                    }
                }
                catch (FormatException fe)
                {
                    Debug.WriteLine(fe);
                    continue;
                }

            }

            stop.Stop();
            Debug.WriteLine(stop.Elapsed);
    }

    }



}
