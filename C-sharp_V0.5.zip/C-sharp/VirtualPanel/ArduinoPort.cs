﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace VirtualPanel
{
    class ArduinoPort
    {
        private readonly String ID;
        
        public Boolean IsConnected { get { return connected; } }
        public String Debug_Data { get; private set; }
        public TimeSpan SearchPortTimeout { get; set; }
        public TimeSpan SearchPollFrequency { get; set; }

        private bool connected = false;
        private SerialPort port;
        private BackgroundWorker port_finder;
        private String read_buffer;

        public event EventHandler<MessageReceivedEventArgs> MessageReceived;
        public event EventHandler<ConnectedEventArgs> Connected;
        public event EventHandler<ConnectedEventArgs> Disconnected;

        #region Initialization

        public ArduinoPort(string id, int baudrate = 115200, TimeSpan timeout = default(TimeSpan))
        {
            if (timeout == default(TimeSpan))
                SearchPortTimeout = TimeSpan.FromMilliseconds(500);
            else
                SearchPortTimeout = timeout;


            SearchPollFrequency = TimeSpan.FromMilliseconds(100);

            ID = id;

            // Set up port object.
            port = new SerialPort();
            SetUpPort();

            // Create Backgroundworker.
            port_finder = new BackgroundWorker();

            // Set properties
            port_finder.WorkerSupportsCancellation = true;
            port_finder.WorkerReportsProgress = false;

            // Attach event handlers.
            port_finder.DoWork += Port_finder_DoWork;
            port_finder.RunWorkerCompleted += Port_finder_RunWorkerCompleted;

            //port.DataReceived += Port_DataReceived;
            port.ErrorReceived += Port_ErrorReceived;
            //TEMP
            port_finder.RunWorkerAsync();
        }

        private void Port_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            Debug_Data += "[EVENT-ERROR]" + e + "\n";
            Debug.WriteLine("Shit done broke! " + e.EventType);
        }

        private void SetUpPort()
        {
            port.BaudRate = 115200;
            port.Parity = Parity.None;
            port.DataBits = 8;
            port.StopBits = StopBits.One;
            port.Handshake = Handshake.None;
            port.RtsEnable = true;
            port.NewLine = "\r\n";
            port.ReadTimeout = 500;
        }

        #endregion

        #region Port Finding Worker

        private void Port_finder_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
                return;

            Debug.WriteLine("Port found " + port.PortName);

            read_buffer = "";

            // Reattach handler.
            port.DataReceived += Port_DataReceived;

            Connected?.ThreadAwareRaise(this, new ConnectedEventArgs(port.PortName));

            connected = true;
        }

        /// <summary>
        /// Attempts to find a port with a matching ID such that we can use the communication.
        /// </summary>
        /// <param name="sender">Event Sender</param>
        /// <param name="e">Empty</param>
        private void Port_finder_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker owner = sender as BackgroundWorker;

            // While we haven't found a port.
            while (!connected)
            {
                foreach (String name in SerialPort.GetPortNames())
                {
                    Debug.WriteLine(name);
                    if (owner.CancellationPending)
                    {
                        e.Cancel = true;
                        return;
                    }

                    try
                    {
                        if (port.IsOpen) port.Close();
                        port.PortName = name;
                        port.Open();

                        DateTime then = DateTime.Now + SearchPortTimeout;
                        DateTime send_id = DateTime.Now + SearchPollFrequency;

                        while (then > DateTime.Now)
                        {
                            if (send_id < DateTime.Now)
                            {
                                Debug_Data += "[" + port.PortName + " -SENT]: " + "ID\r\n".ToLiteral() + "\n";
                                port.WriteLine("ID");
                                send_id = DateTime.Now + SearchPollFrequency;
                            }
                            
                            string temp = port.ReadExisting();

                            Debug_Data += temp != "" ? "[" + port.PortName + " - RECEIVED]: " + temp.ToLiteral() + "\n" : "";
                            read_buffer += temp;

                            if (temp != "")
                                Debug.WriteLine(temp);

                            string[] chunks = read_buffer.Split(port.NewLine.ToCharArray(), StringSplitOptions.None);

                            read_buffer = "";

                            if (chunks.Last() != "")
                            {
                                read_buffer = chunks.Last();
                                chunks[chunks.Length - 1] = "";
                            }

                            foreach (var data in chunks)
                            {
                                if (data.Contains(ID))
                                    return;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug_Data += "[S-ERROR]: " + ex + "\n";
                        Debug.WriteLine(ex.ToString() + ex.Message);
                        continue;
                    }

                    port.Close();
                }

                Thread.Sleep(SearchPortTimeout);
            }
        }

        #endregion

        private void Disconnect(Boolean start = true)
        {
            connected = false;
            port.DataReceived -= Port_DataReceived;

            Debug.WriteLine(start);

            // Thread Sync Operation.
            if (start) // connection is lost
            {
                port_finder.RunWorkerAsync();
            }
            else // disconnect is requested from UI
            {
                Thread.Sleep(300);
                port.Close();
            }
        }

        #region Port IO Functions

        // Write to Arduino port (GUI thread)
        public void Write(string data)
        {
            if (connected && port.IsOpen)
            {
                try
                {
                    Debug_Data += "[SENT]: " + data.ToLiteral() + "\n";
                    port.WriteLine(data);
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.ToString() + e.Message);
                    Disconnect();
                }
            }
        }

        // Attached to port receive event (PORT thread)
        private void Port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (!(connected && port.IsOpen))
                return;

            string temp = port.ReadExisting();

            Debug_Data += "[RECEIVED]:" + temp.ToLiteral() + "\n";
            read_buffer += temp;

            string[] chunks = read_buffer.Split(port.NewLine.ToCharArray(), StringSplitOptions.None);

            for (int i = 0; i < chunks.Length; i++)
            {
                Debug_Data += "[CHUNK|" + i + "] " + chunks[i].ToLiteral();
            }
            Debug_Data += "\n";

            read_buffer = "";

            if (chunks.Last() != "")
            {
                read_buffer = chunks.Last();
                chunks[chunks.Length - 1] = "";
            }

            foreach (var data in chunks)
            {
                Debug.WriteLine(data);

                if (data.Length < 3)
                    continue;

                int channel;
                if (!int.TryParse(data.Substring(0, 2), NumberStyles.HexNumber, null, out channel))
                    continue;

                int type_temp;
                if (!int.TryParse(data.Substring(2, 1), NumberStyles.HexNumber, null, out type_temp))
                    continue;

                vp_type type = (vp_type) type_temp;

                string value_string = data.Substring(3, data.Length-3);
                object messagedata = null;

                try
                {
                    switch (type)
                    {
                        case vp_type.vp_string:
                            messagedata = value_string;
                            break;
                        case vp_type.vp_boolean:
                            messagedata = Convert.ToBoolean(Convert.ToInt32(value_string, 16));
                            break;
                        case vp_type.vp_byte:
                            messagedata = Convert.ToByte(Convert.ToInt32(value_string, 16));
                            break;
                        case vp_type.vp_int:
                            messagedata = Convert.ToInt32(value_string, 16);
                            break;
                        case vp_type.vp_uint:
                            messagedata = Convert.ToUInt32(value_string, 16);
                            break;
                        case vp_type.vp_long:
                            messagedata = Convert.ToInt64(value_string, 16);
                            break;
                        case vp_type.vp_ulong:
                            messagedata = Convert.ToUInt64(value_string, 16);
                            break;
                    }
                }
                catch (FormatException fe)
                {
                    Debug.WriteLine(fe);
                    Debug_Data += "[ERROR]" + fe;
                    continue;
                }

                MessageReceived?.ThreadAwareRaise(this, new MessageReceivedEventArgs(channel, type, messagedata));
            }
        }

        #endregion

        public void Send(int chanel)
        {

        }

    }
}
