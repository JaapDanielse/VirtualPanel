﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VirtualPanel
{
    public partial class SettingsForm : Form
    {
 
        public SettingsForm()
        {
            InitializeComponent();
        }

        public void WriteMonitor(String inputline)
        {
            if (ArduinoMonitorTextBox.Lines.Length >= 1000)
                ArduinoMonitorTextBox.Text = "";
            ArduinoMonitorTextBox.AppendText(inputline + "\n");
        }

        public void WriteStatus(String inputline)
        {
            StatusLine.Text = inputline;
        }

        private void SettingsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Visible = false;
            e.Cancel = true;
        }

    }
}
