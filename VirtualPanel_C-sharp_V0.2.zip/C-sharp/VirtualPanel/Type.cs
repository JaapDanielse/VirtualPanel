﻿namespace VirtualPanel
{
    enum vp_type
    {
        vp_void,
        vp_string,
        vp_boolean,
        vp_byte,
        vp_int,
        vp_uint,
        vp_long,
        vp_ulong,

        vp_error
    };
}
