﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VirtualPanel
{
    class MessageReceivedEventArgs : EventArgs
    {
        public int ChannelID { get; }
        public vp_type Type { get; }
        public object Data { get; }

        public MessageReceivedEventArgs(int channel, vp_type type, object data)
        {
            ChannelID = channel;
            Type = type;
            Data = data;
        }
    }
}