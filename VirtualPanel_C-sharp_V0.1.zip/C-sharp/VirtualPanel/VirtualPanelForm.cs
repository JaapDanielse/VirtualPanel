﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace VirtualPanel
{
    public partial class VirtualPanelForm : Form
    {
        private SettingsForm settings;
        private StatisticsForm stats;
        private ArduinoPort port;

        private enum ChannelId : int
        {
            command_0,
            command_1,

            set_visible,
            set_invisible,

            button_1,
            button_2,

            led_1,
            button_3,
            led_2,
            button_4,
            led_3,
            button_5,
            led_4,
            button_6,
            led_5,
            button_7,
            led_6,
            button_8,

            button_9,
            button_10,
            led_7,
            button_11,
            Scrollbar_1,

            button_12,
            button_13,
            led_8,
            button_14,
            Scrollbar_2,

            button_15,
            button_16,
            led_9,
            button_17,
            Scrollbar_3,

            led_10,
            display_1,
            led_12,

            led_11,
            display_2,
            led_13
        }




        public VirtualPanelForm()
        {
            InitializeComponent();

            stats = new StatisticsForm();

            settings = new SettingsForm();
            settings.Visible = false;

            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            //button13.Visible = false;
            button14.Visible = false;
            button15.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            Led1.Visible = false;
            Led2.Visible = false;
            Led3.Visible = false;
            Led4.Visible = false;
            Led5.Visible = false;
            Led6.Visible = false;
            Led7.Visible = false;
            Led8.Visible = false;
            Led9.Visible = false;
            Led10.Visible = false;
            Led11.Visible = false;
            Led12.Visible = false;
            Led13.Visible = false;
            display1.Text = "0.00";
            display2.Text = "0.00";
            button3.Font = new Font("Wingdings 2", 14);
            button3.Text = "";
            button10.Font = new Font("Wingdings 3", 14);
            button10.Text = "";
            button12.Font = new Font("Wingdings 3", 14);
            button12.Text = "";
            button13.Font = new Font("Wingdings", 14);
            button13.Text = "";
            button14.Font = new Font("Wingdings 3", 14);
            button14.Text = "";
            button16.Font = new Font("Wingdings 3", 14);
            button16.Text = "";

            port = new ArduinoPort("[test]");
            port.MessageReceived += Port_MessageReceived;
        }

        private void Port_MessageReceived(object sender, MessageReceivedEventArgs mse)
        {
            Debug.WriteLine("Channel: " + mse.ChannelID + " Type: " + mse.Type + " Data: " + mse.Data);
            DisplayArduinoData("Channel: " + mse.ChannelID + " Type: " + mse.Type + " Data: " + mse.Data);

            if ((ChannelId)mse.ChannelID == ChannelId.set_visible)  InitPanel((int) mse.Data);


        }

        private void InitPanel(int componentId)
        {
                switch ((ChannelId)componentId)
                {
                    case ChannelId.button_1:  { button1.Visible = true; break; }
                    case ChannelId.button_2:  { button2.Visible = true; break; }
                    case ChannelId.button_3:  { button3.Visible = true; break; }
                    case ChannelId.button_4:  { button4.Visible = true; break; }
                    case ChannelId.button_5:  { button5.Visible = true; break; }
                    case ChannelId.button_6:  { button6.Visible = true; break; }
                    case ChannelId.button_7:  { button7.Visible = true; break; }
                    case ChannelId.button_8:  { button8.Visible = true; break; }
                    case ChannelId.button_9:  { button9.Visible = true; break; }
                    case ChannelId.button_10: { button10.Visible = true; break; }
                    case ChannelId.button_11: { button11.Visible = true; break; }
                    case ChannelId.button_12: { button12.Visible = true; break; }
                    case ChannelId.button_13: { button13.Visible = true; break; }
                    case ChannelId.button_14: { button14.Visible = true; break; }
                    case ChannelId.button_15: { button15.Visible = true; break; }
                    case ChannelId.button_16: { button16.Visible = true; break; }
                    case ChannelId.button_17: { button17.Visible = true; break; }
                    default: break;
                }
            
        }



        #region Port data
        private void DisplayArduinoData(string data)
        {
            settings.WriteMonitor(data);
        }
        #endregion

        #region Event Handlers Buttons

        private void button_Setup_Click(object sender, EventArgs e)
        {
            if (settings.Visible == true)
            {
                //led_Setup.BackColor = Color.Gray;
                settings.Visible = false;
            }
            else
            {
                settings.Location = new Point(Location.X, Location.Y + Height);
                //led_Setup.BackColor = Color.Yellow;
                settings.Visible = true;
            }
        }



        #endregion

        private void button13_Click(object sender, EventArgs e)
        {
            port.WriteArduinoPort("0111");
        }

    }
}
