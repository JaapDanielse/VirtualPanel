﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VirtualPanel
{
    public partial class SettingsForm : Form
    {
        private int lines = 0;
        private ArduinoPort arduinoport;

        public SettingsForm(ArduinoPort port)
        {
            arduinoport = port;
            InitializeComponent();
        }

        public void WriteMonitor(String inputline)
        {
            if (lines >= 1000)
            {
                ArduinoMonitorTextBox.Text = "";
                lines = 0;
            }

            ArduinoMonitorTextBox.AppendText(inputline + "\n");
            lines++;

        }

        public void WriteStatus(String inputline)
        {
            StatusLine.Text = inputline;
        }

        private void SettingsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Visible = false;
            e.Cancel = true;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            arduinoport.Reset();
        }
    }
}
