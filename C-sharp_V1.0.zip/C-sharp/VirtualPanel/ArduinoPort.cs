﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO.Ports;
using System.Linq;
using System.Threading;

namespace VirtualPanel
{
    public class ArduinoPort
    {
        private readonly String ID;

        public Boolean IsConnected { get { return connected; } }
        public TimeSpan SearchPortTimeout { get; set; } = TimeSpan.FromMilliseconds(2000);
        public TimeSpan SearchPollFrequency { get; set; } = TimeSpan.FromMilliseconds(500);
        public int BaudRate { get { return port.BaudRate; } }

        private bool connected = false;
        private SerialPort port;
        private BackgroundWorker port_finder;
        private String read_buffer;
        private System.Timers.Timer checkPort = new System.Timers.Timer(100);

        public event EventHandler<MessageEventArgs> MessageReceived;
        public event EventHandler<MessageEventArgs> MessageSent;
        public event EventHandler<ConnectedEventArgs> Connected;
        public event EventHandler<ConnectedEventArgs> Disconnected;

        public ArduinoPort(string id, int baudrate = 115200)
        {
            ID = id;

            // Set up port object.
            port = new SerialPort();
            port.BaudRate = baudrate;
            port.Parity = Parity.None;
            port.DataBits = 8;
            port.StopBits = StopBits.One;
            port.Handshake = Handshake.None;
            port.RtsEnable = true;
            port.NewLine = "\r\n";

            // Setup port checker timer.
            checkPort.Elapsed += CheckPort_Elapsed;

            // Create Backgroundworker.
            port_finder = new BackgroundWorker();

            // Set properties
            port_finder.WorkerSupportsCancellation = true;
            port_finder.WorkerReportsProgress = false;

            // Attach event handlers.
            port_finder.DoWork += Port_finder_DoWork;
            port_finder.RunWorkerCompleted += Port_finder_RunWorkerCompleted;

        }

        private void CheckPort_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (connected && !port.IsOpen)
                Disconnect(true);
        }

        public void Open()
        {
            if (!connected && !port_finder.IsBusy)
                port_finder.RunWorkerAsync();
        }

        public void Close()
        {
            Disconnect(false);
        }


        public void Reset()
        {
            port.DtrEnable = false;
            port.DtrEnable = true;

            Disconnect(true);
        }


        #region Port Finding Worker

        private void Port_finder_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
                return;

            Debug.WriteLine("Port found " + port.PortName);

            read_buffer = "";

            // Reattach handler.
            port.DataReceived += Port_DataReceived;
            checkPort.Start();

            connected = true;
            Connected?.ThreadAwareRaise(this, new ConnectedEventArgs(port.PortName));

        }


        /// <summary>
        /// Attempts to find a port with a matching ID such that we can use the communication.
        /// </summary>
        /// <param name="sender">Event Sender</param>
        /// <param name="e">Empty</param>
        private void Port_finder_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker owner = sender as BackgroundWorker;

            // While we haven't found a port.
            while (!connected)
            {
                foreach (String name in SerialPort.GetPortNames())
                {
                    Debug.WriteLine(name);
                    if (owner.CancellationPending)
                    {
                        e.Cancel = true;
                        return;
                    }

                    if (port.IsOpen) port.Close();
                    port.PortName = name;
                    port.Open();

                    DateTime then = DateTime.Now + SearchPortTimeout;
                    DateTime send_id = DateTime.Now + SearchPollFrequency;

                    while (then > DateTime.Now)
                    {
                        if (send_id < DateTime.Now)
                        {
                            port.WriteLine("ID");
                            send_id = DateTime.Now + SearchPollFrequency;
                        }

                        read_buffer += port.ReadExisting();

                        Debug.Write(read_buffer);

                        string[] chunks = read_buffer.Split(new string[] { port.NewLine }, StringSplitOptions.None);

                        read_buffer = "";

                        if (chunks.Last() != "")
                        {
                            read_buffer = chunks.Last();
                            chunks[chunks.Length - 1] = "";
                        }

                        foreach (var data in chunks)
                        {
                            if (data.Contains(ID))
                                return;
                        }

                        Thread.Sleep((int)SearchPollFrequency.TotalMilliseconds);
                    }

                    port.Close();
                }

                Thread.Sleep((int)SearchPollFrequency.TotalMilliseconds);
            }
        }

        #endregion

        private void Disconnect(bool restart)
        {
            connected = false;
            port.DataReceived -= Port_DataReceived;
            checkPort.Stop();

            if (restart) // Connection is lost
                port_finder.RunWorkerAsync();

            else        // Disconnect is requested from UI
                port.Close();

            Disconnected.ThreadAwareRaise(this, new ConnectedEventArgs(port.PortName));
        }

        #region Port IO Functions


        public void Send(byte channel, bool data)
        {
            SendMessage(channel, vp_type.vp_boolean, Convert.ToInt16(Convert.ToBoolean(data)).ToString("X"));
        }

        public void Send(byte channel, string data)
        {
            SendMessage(channel, vp_type.vp_string, data);
        }

        public void Send(byte channel)
        {
            SendMessage(channel, vp_type.vp_void, "");
        }

        public void Send(byte channel, vp_type type, long data)
        {
            String hexdata = "";

            try {

                switch (type)
                {
                    case vp_type.vp_byte:
                        hexdata = Convert.ToByte(data).ToString("X2"); break;
                    case vp_type.vp_int:
                        hexdata = Convert.ToInt16(data).ToString("X4"); break;
                    case vp_type.vp_uint:
                        hexdata = Convert.ToUInt16(data).ToString("X4"); break;
                    case vp_type.vp_long:
                        hexdata = Convert.ToInt32(data).ToString("X8"); break;
                    case vp_type.vp_ulong:
                        hexdata = Convert.ToUInt32(data).ToString("X8"); break;
                    default:
                        throw new InvalidOperationException("Non numeric vp_type with numeric data.");
                }
            }
            catch (OverflowException oe)
            {
                throw new OverflowException("Numeric data not compatible with: " + type.ToString(), oe);
            }

           SendMessage(channel, type, hexdata);
        }

        // Wrapper for converted Send functions helps with even and prevents duplicate code.
        private void SendMessage(byte channel, vp_type type, string data)
        {
            String message = channel.ToString("X2") + ((byte)type).ToString("X1") + data;
            this.Write(message);
            MessageSent?.ThreadAwareRaise(this, new MessageEventArgs(channel, type, data));
        }

        // Write to Arduino port (GUI thread)
        public void Write(string data)
        {
            // Suppress any disconnected calls.
            if (!connected)
                throw new InvalidOperationException("Arduino Port is not connected.");

            Debug.WriteLine(data);

            if (port.IsOpen)
                port.WriteLine(data);
            else // If we are connected but the port is not open we need to update internal state, and notify.
                Disconnect(true);
        }

        // Attached to port receive event (PORT thread)
        private void Port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (!(connected && port.IsOpen))
                return;

            string temp = port.ReadExisting();

            read_buffer += temp;

            string[] chunks = read_buffer.Split(new string[] { port.NewLine }, StringSplitOptions.None);

            read_buffer = "";

            if (chunks.Last() != "")
            {
                read_buffer = chunks.Last();
                chunks[chunks.Length - 1] = "";
            }

            foreach (var data in chunks)
            {
                Debug.WriteLine(data);

                if (data.Length < 3)
                    continue;

                int channel;
                if (!int.TryParse(data.Substring(0, 2), NumberStyles.HexNumber, null, out channel))
                    continue;

                int type_temp;
                if (!int.TryParse(data.Substring(2, 1), NumberStyles.HexNumber, null, out type_temp))
                    continue;

                vp_type type = (vp_type)type_temp;

                string value_string = data.Substring(3, data.Length - 3);
                object messagedata = null;

                try
                {
                    switch (type)
                    {
                        case vp_type.vp_string:
                            messagedata = value_string;
                            break;
                        case vp_type.vp_boolean:
                            messagedata = Convert.ToBoolean(Convert.ToInt32(value_string, 16));
                            break;
                        case vp_type.vp_byte:
                            messagedata = Convert.ToByte(Convert.ToInt32(value_string, 16));
                            break;
                        case vp_type.vp_int:
                            messagedata = Convert.ToInt32(value_string, 16);
                            break;
                        case vp_type.vp_uint:
                            messagedata = Convert.ToUInt32(value_string, 16);
                            break;
                        case vp_type.vp_long:
                            messagedata = Convert.ToInt64(value_string, 16);
                            break;
                        case vp_type.vp_ulong:
                            messagedata = Convert.ToUInt64(value_string, 16);
                            break;
                    }
                }
                catch (FormatException fe)
                {
                    Debug.WriteLine(fe);
                    continue;
                }

                MessageReceived?.ThreadAwareRaise(this, new MessageEventArgs(channel, type, messagedata));
            }
        }

        #endregion

    }
}
