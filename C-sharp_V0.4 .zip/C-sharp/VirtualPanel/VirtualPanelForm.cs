﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace VirtualPanel
{
    enum ChannelId
    {
        //
        ApplicationName,
        PanelConnected,
        StaticDisplay,
        DynamicDisplay,
        //
        button_1,
        button_2,
        button_3,
        button_4,
        button_5,
        button_6,
        button_7,
        button_8,
        //
        button_9,
        button_10,
        button_11,
        button_12,
        button_13,
        button_14,
        button_15,
        button_16,
        button_17,
        //
        scrollbar_1,
        scrollbar_2,
        scrollbar_3,
        //
        led_1,
        led_2,
        led_3,
        led_4,
        led_5,
        led_6,
        led_7,
        led_8,
        led_9,
        led_10,
        led_11,
        led_12,
        led_13,
        //
        display_1,
        display_2,
        display_3,
        display_4,
        //
        StatField1,
        StatField2,
        StatField3,
        StatField4,
        StatField5,
        StatField6,
        //
        StatMonitor
    }



    public partial class VirtualPanelForm : Form
    {
        private SettingsForm settings;
        private StatisticsForm stats;
        private ArduinoPort port;
        private List<Tuple<ChannelId, Control>> pannelControlList;


        public VirtualPanelForm()
        {
            InitializeComponent();

            pannelControlList = new List<Tuple<ChannelId, Control>>();

            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_1, button1));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_2, button2));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_3, button3));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_4, button4));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_5, button5));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_6, button6));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_7, button7));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_8, button8));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_9, button9));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_10, button10));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_11, button11));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_12, button12));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_13, button13));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_14, button14));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_15, button15));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_16, button16));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.button_17, button17));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_1, Led1));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_2, Led2));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_3, Led3));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_4, Led4));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_5, Led5));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_6, Led6));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_7, Led7));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_8, Led8));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_9, Led9));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_10, Led10));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_11, Led11));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_12, Led12));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.led_13, Led13));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.ApplicationName, ApplicationTitle));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.display_1, display1));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.display_2, display2));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.display_3, display3));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.display_4, display4));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.scrollbar_1, ScrollBar1));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.scrollbar_2, ScrollBar2));
            pannelControlList.Add(new Tuple<ChannelId, Control>(ChannelId.scrollbar_3, ScrollBar3));



            stats = new StatisticsForm();
            stats.Visible = false;
            settings = new SettingsForm();
            settings.Visible = false;

            foreach (var t in pannelControlList)
            {
                t.Item2.Visible = false;
            }

            scrolllabel1.Visible = false;
            scrolllabel2.Visible = false;
            scrolllabel3.Visible = false;

            display1.Text = "";
            display2.Text = "";
            display3.Text = "";
            display4.Text = "";

            display3.BringToFront();
            display4.BringToFront();

            button3.Select();


            Debug.WriteLine(" button 17 hex > " + string.Format("{0:X2}", (byte)ChannelId.PanelConnected) + "0");


            port = new ArduinoPort("[PANEL01V01]");
            port.Connected += Port_Connected;
            port.MessageReceived += Port_MessageReceived;

        }

        private void Port_Connected(object sender, ConnectedEventArgs args)
        {
            connection_label.Text = args.Portname;
            connected_box.BackColor = Color.Lime;
            port.Write(string.Format("{0:X2}", (byte)ChannelId.PanelConnected) + "0");
            Debug.WriteLine("Port " + args.Portname + " connected");
            port.Write(string.Format("{0:X2}", (byte)ChannelId.StaticDisplay) + "0");
        }

        private void Port_MessageReceived(object sender, MessageReceivedEventArgs mse)
        {
            Debug.WriteLine("Channel: " + mse.ChannelID + " Type: " + mse.Type + " Data: " + mse.Data);
            DisplayArduinoData("Channel: " + mse.ChannelID + " Type: " + mse.Type + " Data: " + mse.Data);

            Tuple<ChannelId, Control> control = pannelControlList.Find(t => t.Item1 == (ChannelId)mse.ChannelID);

            if (control != null)
                SetAppearance(control.Item2, mse);
            else
            {
                if (mse.ChannelID == (int)ChannelId.DynamicDisplay && (bool)mse.Data == true) timer1.Enabled = true;
                if (mse.ChannelID == (int)ChannelId.StaticDisplay && (bool)mse.Data == true) ;
                if (mse.ChannelID == (int)ChannelId.StatField1)  stats.Write_Label(1, " " + mse.Data);
                if (mse.ChannelID == (int)ChannelId.StatField2)  stats.Write_Label(2, " " + mse.Data);
                if (mse.ChannelID == (int)ChannelId.StatField3)  stats.Write_Label(3, " " + mse.Data);
                if (mse.ChannelID == (int)ChannelId.StatField4)  stats.Write_Label(4, " " + mse.Data);
                if (mse.ChannelID == (int)ChannelId.StatField5)  stats.Write_Label(5, " " + mse.Data);
                if (mse.ChannelID == (int)ChannelId.StatField6)  stats.Write_Label(6, " " + mse.Data);
                if (mse.ChannelID == (int)ChannelId.StatMonitor) stats.WriteMonitor( " " + mse.Data);
            }
        }

        private void SetAppearance(Control control, MessageReceivedEventArgs mse)
        {
            if (control is Button) SetButtonAppearance((Button)control, mse);
            if (control is PictureBox) SetLedAppearance((PictureBox)control, mse);
            if (control is Label) SetDisplayAppearance((Label)control, mse);
            if (control is VScrollBar) SetScrollBarAppearance((VScrollBar)control, mse);
        }


        private void SetButtonAppearance(Button button, MessageReceivedEventArgs mse)
        {
            int channelId = mse.ChannelID;

            if (mse.Type == vp_type.vp_boolean && (bool)mse.Data == false)
                button.Visible = false;
            else
                button.Visible = true;

            if (mse.Type == vp_type.vp_string)
            {
                if ((string)mse.Data == "$LEFT")
                {
                    button.Font = new Font("Wingdings 3", 10); //left
                    button.Text = "";
                }
                else if ((string)mse.Data == "$UP")
                {
                    button.Font = new Font("Wingdings 3", 10); //up
                    button.Text = "";
                }
                else if ((string)mse.Data == "$DOT")
                {
                    button.Font = new Font("Wingdings", 10); //center
                    button.Text = "";
                }
                else if ((string)mse.Data == "$DOWN")
                {
                    button.Font = new Font("Wingdings 3", 10); //down
                    button.Text = "";
                }
                else if ((string)mse.Data == "$RIGHT")
                {
                    button.Font = new Font("Wingdings 3", 10); //right
                    button.Text = "";
                }
                else if ((string)mse.Data == "$SET")
                {
                    button.Font = new Font("Wingdings 2", 10); //right
                    button.Text = "";
                }
                else if ((string)mse.Data == "$ONOFF")
                {
                    button.Font = new Font("Wingdings 2", 8); //right
                    button.Text = "";
                }
                else
                {
                    button.Font = new Font("Microsoft Sans Serif", 8); //right
                    button.Text = (string)mse.Data;
                }
            }
        }

        private void SetLedAppearance(PictureBox led, MessageReceivedEventArgs mse)
        {
            int channelId = mse.ChannelID;

            if (mse.Type == vp_type.vp_boolean && (bool)mse.Data == false)
                led.Visible = false;
            else
                led.Visible = true;

            if (mse.Type == vp_type.vp_string)
            {
                if ((string)mse.Data == "$OFF") led.BackColor = Color.Black;
                if ((string)mse.Data == "$RED") led.BackColor = Color.Red;
                if ((string)mse.Data == "$GREEN") led.BackColor = Color.Lime;
                if ((string)mse.Data == "$YELLOW") led.BackColor = Color.Yellow;
                if ((string)mse.Data == "$ORANGE") led.BackColor = Color.Orange;
            }
        }


        private void SetDisplayAppearance(Label display, MessageReceivedEventArgs mse)
        {
            int channelId = mse.ChannelID;

            if (mse.Type == vp_type.vp_boolean && (bool)mse.Data == false)
                display.Visible = false;
            else
                display.Visible = true;

            if (mse.Type == vp_type.vp_string)
            {
                if ((string)mse.Data == "$BOLD")
                    display.Font = new Font(display.Font, FontStyle.Bold);
                else if ((string)mse.Data == "$NORMAL")
                    display.Font = new Font(display.Font, FontStyle.Regular);
                else
                    display.Text = (string)mse.Data;
            }
        }

        private void SetScrollBarAppearance(VScrollBar scrollBar, MessageReceivedEventArgs mse)
        {
            int channelId = mse.ChannelID;

            if (mse.Type == vp_type.vp_boolean && (bool)mse.Data == false)
            {
                scrollBar.Visible = false;
                if (scrollBar.Name == "ScrollBar1") scrolllabel1.Visible = false;
                if (scrollBar.Name == "ScrollBar2") scrolllabel2.Visible = false;
                if (scrollBar.Name == "ScrollBar3") scrolllabel3.Visible = false;
            }
            else
            {
                scrollBar.Visible = true;
                if (mse.Type == vp_type.vp_string)
                {
                    if (scrollBar.Name == "ScrollBar1")
                    {
                        scrolllabel1.Visible = true;
                        scrolllabel1.Text = (string)mse.Data;
                        button9.Visible = false;
                        button10.Visible = false;
                        button11.Visible = false;

                    }
                    if (scrollBar.Name == "ScrollBar2")
                    {
                        scrolllabel2.Visible = true;
                        scrolllabel2.Text = (string)mse.Data;
                        button12.Visible = false;
                        button13.Visible = false;
                        button14.Visible = false;
                    }
                    if (scrollBar.Name == "ScrollBar3")
                    {
                        scrolllabel3.Visible = true;
                        scrolllabel3.Text = (string)mse.Data;
                        button15.Visible = false;
                        button16.Visible = false;
                        button17.Visible = false;

                    }
                }
                if (mse.Type == vp_type.vp_int)
                {
                    if (scrollBar.Name == "ScrollBar1") ScrollBar1.Value = ((ScrollBar1.Maximum - 9) - (int)mse.Data);
                    if (scrollBar.Name == "ScrollBar2") ScrollBar2.Value = ((ScrollBar2.Maximum - 9) - (int)mse.Data);
                    if (scrollBar.Name == "ScrollBar3") ScrollBar3.Value = ((ScrollBar3.Maximum - 9) - (int)mse.Data);
                }
            }
        }

        #region Port data
        private void DisplayArduinoData(string data)
        {
            settings.WriteMonitor(data);
        }
        #endregion

        #region Event Handlers Buttons

        private void button_Setup_Click(object sender, EventArgs e)
        {
            if (settings.Visible == true)
            {
                //led_Setup.BackColor = Color.Gray;
                settings.Visible = false;
            }
            else
            {
                settings.Location = new Point(Location.X, Location.Y + Height);
                //led_Setup.BackColor = Color.Yellow;
                settings.Visible = true;
            }
        }

        private void Button_Statistics_Click(object sender, EventArgs e)
        {
            if (stats.Visible == true)
            {
                //led_Setup.BackColor = Color.Gray;
                stats.Visible = false;
            }
            else
            {
                stats.Location = new Point(Location.X, Location.Y + Height);
                //led_Setup.BackColor = Color.Yellow;
                stats.Visible = true;
            }
        }
        #endregion

        private void button_Click(object sender, EventArgs e)
        {
            Tuple<ChannelId, Control> channel = pannelControlList.Find(t => t.Item2 == sender);
            if (channel != null)
            {
                port.Write(string.Format("{0:X2}", (byte)channel.Item1) + "0");
                Debug.WriteLine("button:" + string.Format("{0:X2}", (byte)channel.Item1) + "0");
                // port.Write(string.Format("{0:X2}", (byte)ChannelId.StaticDisplay) + "0");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            port.Write(string.Format("{0:X2}", (byte)ChannelId.DynamicDisplay) + "0");

        }

        private void ScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            Tuple<ChannelId, Control> channel = pannelControlList.Find(t => t.Item2 == sender);
            if (channel != null)
            {
                VScrollBar temp = (VScrollBar)channel.Item2;
                int Value = (temp.Maximum - 9) - temp.Value ;
                Debug.WriteLine("ScrollBar:" + string.Format("{0:X2}", (byte)channel.Item1) + "4" + string.Format("{0:X4}", Value));
                port.Write(string.Format("{0:X2}", (byte)channel.Item1) + "4" + string.Format("{0:X4}", Value));
            }
        }

        private void VirtualPanelForm_FormClosed(object sender, FormClosedEventArgs e)
        {
           // System.IO.File.WriteAllText(@"DEBUG_OUTPUT.txt", port.Debug_Data);
        }
    }
}
