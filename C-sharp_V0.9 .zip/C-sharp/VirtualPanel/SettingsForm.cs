﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VirtualPanel
{
    public partial class SettingsForm : Form
    {
        private int lines = 0;
        private ArduinoPort arduinoport;
        private int MsgNum = 0;

        public SettingsForm(ArduinoPort port)
        {
            arduinoport = port;
            InitializeComponent();
            arduinoport.MessageSent += Arduinoport_MessageSent;
            arduinoport.MessageReceived += Arduinoport_MessageReceived;
        }

        private void Arduinoport_MessageReceived(object sender, MessageEventArgs e)
        {
            WriteMonitor(MsgNum++ + "  R  " + ((ChannelId)e.ChannelID).ToString() + "\t" + e.Type.ToString() + "\t" + e.Data.ToString());
        }

        private void Arduinoport_MessageSent(object sender, MessageEventArgs e)
        {
            WriteMonitor(MsgNum++ + "  S  " + ((ChannelId)e.ChannelID).ToString() + "\t" + e.Type.ToString() + "\t" + e.Data);

        }

        public void WriteMonitor(String inputline)
        {
            if (lines >= 1000)
            {
                ArduinoMonitorTextBox.Text = "";
                lines = 0;
            }

            ArduinoMonitorTextBox.AppendText(inputline + "\n");
            lines++;

        }

        private void SettingsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Visible = false;
            e.Cancel = true;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            arduinoport.Reset();
        }
    }
}
